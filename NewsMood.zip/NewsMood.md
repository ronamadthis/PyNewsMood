

```python
# Dependencies
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
import tweepy
import time
import seaborn as sns

# Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
consumer_key = ""
consumer_secret = ""
access_token = ""
access_token_secret = ""

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
# Target search Term
target_terms = ("@BBC", "@CBS","@CNN", "@Fox", "@nytimes")
```


```python
# Counter
# counter = 1

# Variables for holding sentiments
sentiments = []
```


```python
# Loop through all target users
for target in target_terms:

    # Variables for holding sentiments
    compound_list = []
    positive_list = []
    negative_list = []
    neutral_list = []
    
    counter=1
    # Loop through 5 pages of tweets (total 100 tweets)
    for x in range(5):
    
        # Get all tweets from home feed
        public_tweets=api.user_timeline(target, page=x)
        #public_tweets = api.search(target_terms, count=100, result_type="recent")
        # Loop through all tweets 
        for tweet in public_tweets:
            
            # Run Vader Analysis on each tweet
            compound = analyzer.polarity_scores(tweet["text"])["compound"]
            pos = analyzer.polarity_scores(tweet["text"])["pos"]
            neu = analyzer.polarity_scores(tweet["text"])["neu"]
            neg = analyzer.polarity_scores(tweet["text"])["neg"]
            tweets_ago = counter
            
            # Add each value to the appropriate array
            compound_list.append(compound)
            positive_list.append(pos)
            negative_list.append(neg)
            neutral_list.append(neu)
            
            # Add sentiments for each tweet into an array
            sentiments.append({"User":target, "Text":tweet["text"], "Date":tweet["created_at"], "Compound": compound, "Positive": pos, "Negative": neg, "Neutral":neu,
                          "Tweets Ago":counter})
            
            # Add to counter 
            counter = counter + 1
            
```


```python
# Convert sentiments to DataFrame
sentiments_pd = pd. DataFrame.from_dict(sentiments)
sentiments_pd.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Text</th>
      <th>Tweets Ago</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>493</th>
      <td>0.3818</td>
      <td>Thu Dec 28 03:10:02 +0000 2017</td>
      <td>0.000</td>
      <td>0.890</td>
      <td>0.110</td>
      <td>Tech companies aren’t going to protect your da...</td>
      <td>96</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>494</th>
      <td>0.0000</td>
      <td>Thu Dec 28 02:57:31 +0000 2017</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>From 52 places to go to pictures from the wome...</td>
      <td>97</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>495</th>
      <td>0.2263</td>
      <td>Thu Dec 28 02:50:33 +0000 2017</td>
      <td>0.000</td>
      <td>0.840</td>
      <td>0.160</td>
      <td>In a jab at President Trump, Gov. Cuomo pardon...</td>
      <td>98</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>496</th>
      <td>-0.3400</td>
      <td>Thu Dec 28 02:40:21 +0000 2017</td>
      <td>0.167</td>
      <td>0.833</td>
      <td>0.000</td>
      <td>RT @nytimesmusic: The pop charts were crazy th...</td>
      <td>99</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>497</th>
      <td>0.3818</td>
      <td>Thu Dec 28 02:40:05 +0000 2017</td>
      <td>0.000</td>
      <td>0.843</td>
      <td>0.157</td>
      <td>Some hamsters and squirrels really do have a s...</td>
      <td>100</td>
      <td>@nytimes</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentiments_pd.sort_values('Tweets Ago', inplace=True)
sentiments_pd.head(10)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Text</th>
      <th>Tweets Ago</th>
      <th>User</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.0772</td>
      <td>Thu Dec 28 20:05:03 +0000 2017</td>
      <td>0.115</td>
      <td>0.791</td>
      <td>0.094</td>
      <td>The theatre shows you won’t want to miss in 20...</td>
      <td>1</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>198</th>
      <td>0.1280</td>
      <td>Thu Dec 28 20:15:13 +0000 2017</td>
      <td>0.158</td>
      <td>0.647</td>
      <td>0.194</td>
      <td>Yes or No? Simple answers to your tax question...</td>
      <td>1</td>
      <td>@CNN</td>
    </tr>
    <tr>
      <th>398</th>
      <td>0.8070</td>
      <td>Thu Dec 28 20:10:08 +0000 2017</td>
      <td>0.000</td>
      <td>0.751</td>
      <td>0.249</td>
      <td>The 25 best movies of the 21st century so far ...</td>
      <td>1</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>100</th>
      <td>0.0000</td>
      <td>Thu Dec 28 19:28:22 +0000 2017</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>Some of TV's biggest stars saluted @TheNormanL...</td>
      <td>1</td>
      <td>@CBS</td>
    </tr>
    <tr>
      <th>298</th>
      <td>0.2960</td>
      <td>Thu Dec 28 10:25:26 +0000 2017</td>
      <td>0.089</td>
      <td>0.732</td>
      <td>0.179</td>
      <td>RT @alicegoldfuss: Two statements that are bot...</td>
      <td>1</td>
      <td>@Fox</td>
    </tr>
    <tr>
      <th>199</th>
      <td>0.7264</td>
      <td>Thu Dec 28 20:00:22 +0000 2017</td>
      <td>0.000</td>
      <td>0.644</td>
      <td>0.356</td>
      <td>Foxconn got a really good deal from Wisconsin....</td>
      <td>2</td>
      <td>@CNN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0000</td>
      <td>Thu Dec 28 19:30:03 +0000 2017</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>This first aid phone app is saving lives.📱🏥\n\...</td>
      <td>2</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>101</th>
      <td>0.8750</td>
      <td>Wed Dec 27 22:45:05 +0000 2017</td>
      <td>0.000</td>
      <td>0.643</td>
      <td>0.357</td>
      <td>The search is on to find the pro football play...</td>
      <td>2</td>
      <td>@CBS</td>
    </tr>
    <tr>
      <th>299</th>
      <td>0.4215</td>
      <td>Thu Dec 28 06:18:02 +0000 2017</td>
      <td>0.000</td>
      <td>0.741</td>
      <td>0.259</td>
      <td>ICYMI: inclusion has to be proactive and inter...</td>
      <td>2</td>
      <td>@Fox</td>
    </tr>
    <tr>
      <th>399</th>
      <td>-0.3182</td>
      <td>Thu Dec 28 19:55:03 +0000 2017</td>
      <td>0.113</td>
      <td>0.887</td>
      <td>0.000</td>
      <td>The Lives They Lived: Remembering some of the ...</td>
      <td>2</td>
      <td>@nytimes</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Save the DataFrame as a csv
sentiments_pd.to_csv("News_outlet_sentiments.csv", encoding="utf-8", index=False)
```


```python
# Create plot
# plt.plot(sentiments_pd["Tweets Ago"], sentiments_pd["Compound"], marker="o", linewidth=0, alpha=0.5)
for index, row in sentiments_pd.iterrows():
    if row['User']== "@CBS":
        cbs=plt.scatter(row["Tweets Ago"], row["Compound"], marker="o", color="green", alpha=0.5)
    elif row['User']== "@CNN":
        cnn=plt.scatter(row["Tweets Ago"], row["Compound"], marker="o", color="red",alpha=0.5)
    elif row['User']== "@BBC":
        bbc=plt.scatter(row["Tweets Ago"], row["Compound"], marker="o", color="cyan",alpha=0.5)    
    elif row['User']== "@Fox":
        fox=plt.scatter(row["Tweets Ago"], row["Compound"], marker="o", color="blue",alpha=0.5)    
    elif row['User']== "@nytimes":
        nytimes=plt.scatter(row["Tweets Ago"], row["Compound"], marker="o", color="yellow",alpha=0.5)    
        
    
# # Incorporate the other graph properties
plt.title("Sentiment Analysis of Media Tweets (%s)" % (time.strftime("%x")))
plt.ylabel("Tweets Polarity")
plt.xlabel("Tweets Ago")
plt.legend(handles=[cbs,cnn,bbc,fox,nytimes],labels=["CBS", "CNN", "BBC", "Fox", "NYTimes"], bbox_to_anchor=(1, 0.5))
sns.set()

# Save the figure
plt.savefig("Sentiment_Analysis.png")

# Plot
plt.show()
```


![png](output_7_0.png)



```python
#groupby_compound=sentiments_pd["Compound"].groupby(sentiments_pd["User"])
#groupby_compound.mean()

grouped=sentiments_pd.groupby('User', as_index=False)
new =grouped.aggregate(np.mean)
new.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User</th>
      <th>Compound</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>0.127773</td>
      <td>0.047960</td>
      <td>0.853820</td>
      <td>0.098200</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@CBS</td>
      <td>0.511610</td>
      <td>0.008959</td>
      <td>0.775143</td>
      <td>0.215929</td>
      <td>49.5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@CNN</td>
      <td>0.006099</td>
      <td>0.087430</td>
      <td>0.827930</td>
      <td>0.084640</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@Fox</td>
      <td>0.145132</td>
      <td>0.068350</td>
      <td>0.798820</td>
      <td>0.132870</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@nytimes</td>
      <td>-0.144849</td>
      <td>0.114960</td>
      <td>0.823910</td>
      <td>0.061130</td>
      <td>50.5</td>
    </tr>
  </tbody>
</table>
</div>




```python
new["User"]=new["User"].replace('@BBC', 'BBC')
new["User"]=new["User"].replace('@CBS', 'CBS')
new["User"]=new["User"].replace('@CNN', 'CNN')
new["User"]=new["User"].replace('@Fox', 'Fox')
new["User"]=new["User"].replace('@nytimes', 'NYT')
new.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User</th>
      <th>Compound</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BBC</td>
      <td>0.127773</td>
      <td>0.047960</td>
      <td>0.853820</td>
      <td>0.098200</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CBS</td>
      <td>0.511610</td>
      <td>0.008959</td>
      <td>0.775143</td>
      <td>0.215929</td>
      <td>49.5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CNN</td>
      <td>0.006099</td>
      <td>0.087430</td>
      <td>0.827930</td>
      <td>0.084640</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Fox</td>
      <td>0.145132</td>
      <td>0.068350</td>
      <td>0.798820</td>
      <td>0.132870</td>
      <td>50.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NYT</td>
      <td>-0.144849</td>
      <td>0.114960</td>
      <td>0.823910</td>
      <td>0.061130</td>
      <td>50.5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Bar plot of Overall Sentiment of each news outlet
colors=["cyan", "green","red", "blue", "yellow"]

plt.bar(range(len(new)), new["Compound"], align='center', color=colors)
plt.xticks(range(len(new)), new["User"])

# # Incorporate the other graph properties
plt.title("Overall Media Sentiment Based on Twitter (%s)" % (time.strftime("%x")))
plt.ylabel("Tweets Polarity")

# Save the figure
plt.savefig("Overall_Media_Sentiment.png")

# Plot
plt.show()
```


![png](output_10_0.png)

